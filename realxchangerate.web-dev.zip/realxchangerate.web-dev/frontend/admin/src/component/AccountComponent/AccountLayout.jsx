import React from 'react'

const AccountLayout = () => {
  return (
    <div>AccountLayout</div>
  )
}

export default AccountLayout