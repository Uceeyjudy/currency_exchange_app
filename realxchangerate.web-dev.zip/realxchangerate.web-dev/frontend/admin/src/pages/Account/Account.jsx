import React from 'react'
import AccountLayout from '../../component/AccountComponent/AccountLayout'

const Account = () => {
  return (
    <AccountLayout/>
  )
}

export default Account