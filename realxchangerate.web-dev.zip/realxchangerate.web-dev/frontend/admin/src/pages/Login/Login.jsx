import React from 'react'
import LoginPage from '../../component/LoginComponent/LoginPage'

const Login = () => {
  return (
    <LoginPage/>
  )
}

export default Login