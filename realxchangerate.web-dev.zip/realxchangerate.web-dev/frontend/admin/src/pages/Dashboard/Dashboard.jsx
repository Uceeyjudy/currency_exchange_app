import React from 'react'
import DashboardLayout from '../../component/DashboardComponent/DashboardLayout'

const Dashboard = () => {
  return (
    <DashboardLayout/>
  )
}

export default Dashboard