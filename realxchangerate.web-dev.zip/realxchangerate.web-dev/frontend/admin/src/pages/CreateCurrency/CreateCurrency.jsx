import React from 'react'

const CreateCurrency = () => {
  return (
    <div>CreateCurrency</div>
  )
}

export default CreateCurrency