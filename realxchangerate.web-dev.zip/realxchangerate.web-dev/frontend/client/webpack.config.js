module.exports = {
    //...
    resolve: {
      alias: {
        '@mui/styled-engine': '@mui/styled-engine-sc'
      },
    },
  };