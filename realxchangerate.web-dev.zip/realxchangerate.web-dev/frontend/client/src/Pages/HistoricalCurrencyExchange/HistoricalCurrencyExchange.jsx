const HistoricalCurrencyExchange = () => {
    return (
        <div>Historical Currency Exchange Page</div>
    )
}

export default HistoricalCurrencyExchange;