import React from 'react'
import CookiePolicyMain from './CookiePolicyMain'

const CookiePolicy = () => {
  return (
    <>
    <CookiePolicyMain/>
    </>
  )
}

export default CookiePolicy