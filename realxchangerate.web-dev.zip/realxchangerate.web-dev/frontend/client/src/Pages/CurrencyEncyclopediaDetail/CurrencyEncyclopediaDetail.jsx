import React from "react";
import Detailpage from "../../components/encyclopedia/detailspage/Detailpage";


const CurrencyEncyclopediaDetail = () => {
  return (
    <div>
      <Detailpage/>
    </div>
  );
};

export default CurrencyEncyclopediaDetail;
