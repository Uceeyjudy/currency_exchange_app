const Convert = () => {
    return (
        <div>Convert Page</div>
    )
}

export default Convert;