import styled from 'styled-components'

export const Arrow = styled.img`
    margin-right:30px;
    cursor:pointer;
    width:20px;
    height:20px
`