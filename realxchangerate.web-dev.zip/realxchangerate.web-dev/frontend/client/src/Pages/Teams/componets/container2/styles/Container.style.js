import styled from "styled-components";

export const Container = styled.section`
  padding: 0 7vw 8vw 7vw;
  width: 100%;

  @media (max-width: 1100px) {
    margin-top: 15vh;
  }
  @media (max-width: 768px) {
  }
`;
