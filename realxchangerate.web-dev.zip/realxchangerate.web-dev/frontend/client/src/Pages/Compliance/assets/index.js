export {default as BackgroundImage} from "./png/background.png"
export {default as BackgroundImageMobile} from "./png/background_mobile.png"
export {default as RightArrow } from "./svg/RightArrow.svg"