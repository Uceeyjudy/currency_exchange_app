import im8 from "../../assets/News_img/world.png";
import im9 from "../../assets/News_img/small.png";

const articles = [
  {
    id: 1,
    img: im8,
    title: "Currency Exchange",
    author: "Chudi Victor",
    date: "November 15, 2022",
    intro:
      "Curriences gained against the greenback as the euro, yen and sterling all rose and the curriences",
  },
  {
    id: 2,
    img: im9,
    title: "Currency Exchange",
    author: "Chudi Victor",
    date: "November 15, 2022",
    intro:
      "Curriences gained against the greenback as the euro, yen and sterling all rose and the curriences",
  },
];

export { articles };
