import Image1 from "../Ambassadors/images/Ellipse 1.png";
import Image2 from "../Ambassadors/images/Ellipse 2.png";
import Image3 from "../Ambassadors/images/Ellipse 3.png";
import Image4 from "../Ambassadors/images/Ellipse 4.png";
import Image5 from "../Ambassadors/images/Ellipse 5.png";
import Image6 from "../Ambassadors/images/Ellipse 6.png";
import Image7 from "../Ambassadors/images/Ellipse 7.png";
import Image8 from "../Ambassadors/images/Ellipse 8.png";

export const people = [
  {
    id: "p1",
    name: "Savannah Nguyen",
    role: "Entrepreneur",
    img: Image1,
  },
  {
    id: "p2",
    name: "Ralph Edwards",
    role: "Entrepreneur",
    img: Image2,
  },
  {
    id: "p3",
    name: "Bessie Cooper",
    role: "Entrepreneur",
    img: Image3,
  },
  {
    id: "p4",
    name: "Marvin McKinney",
    role: "Entrepreneur",
    img: Image4,
  },
  {
    id: "p5",
    name: "Darrell Steward",
    role: "Entrepreneur",
    img: Image5,
  },
  {
    id: "p6",
    name: "Cameron Williamson",
    role: "Entrepreneur",
    img: Image6,
  },
  {
    id: "p7",
    name: "Kristin Watson",
    role: "Entrepreneur",
    img: Image7,
  },
  {
    id: "p8",
    name: "Kathryn Murphy",
    role: "Entrepreneur",
    img: Image8,
  },
];
