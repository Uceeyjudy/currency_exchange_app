import React from "react";
import { Hero, LiveRate } from "./";

const Home = () => {
  return (
    <>
      <Hero />
      <LiveRate />
    </>
  );
};

export default Home;
